var http = require('http');
var fs = require("fs");
var qs = require('querystring');

var MongoClient = require('mongodb').MongoClient;

var dbUrl = "mongodb://localhost:27017/";

http.createServer(function(request, response) {

	if(request.url === "/index"){
		sendFileContent(response, "web.html", "text/html");
	}
	else if(request.url === "/"){
		console.log("Requested URL is url" +request.url);
		response.writeHead(200, {'Content-Type': 'text/html'});
		response.write('<b>Hey there!</b><br /><br />This is the default response. Requested URL is: ' + request.url);
	}
    else if(request.url==="/reg"){
		
        if (request.method === "POST") { 
			return request.on('data', function(data) {
			  return request.on('end', function() {
				var query = {};
				var fmdata = '';
				fmdata += data;
				var info = fmdata.split("&");   
				for(i=0; i<info.length; i++){
					var d=info[i].split("=");
					query[d[0]] = d[1];
				}
				MongoClient.connect(dbUrl, function(err, db) {
					if (err) throw err;
					var dbo = db.db("mydb");
					dbo.collection("customers").insertOne(query, function(err, res) {
						if (err) throw err;
						response.end("SUCCESS"); 
						db.close();
					});
				});// parse back to client side.
			  });

			});
		} else {
			sendFileContent(response, "web.html", "text/html");
		}
              
	}
	else if(request.url==="/checklogin"){
        if (request.method === "POST") { 
			return request.on('data', function(data) {
			  return request.on('end', function() {
				var query = {  };
				var fmdata = '';
				fmdata += data;
				var info = fmdata.split("&");
				for(var i=0; i<info.length; i++){
					var d = info[i].split("=");
					query[d[0]] = d[1];
				}	
				MongoClient.connect(dbUrl, function(err, db) {
					if (err) throw err;
					var dbo = db.db("mydb");
					dbo.collection("customers").find(query).toArray(function(err, res) {
						if (err) throw err;
						res == "" ? response.end("FAIL") : response.end("SUCCESS"); 
						db.close();
					});
				});
			  });

			});
		} else {
			sendFileContent(response, "web.html", "text/html");
		}
	}else if(request.url==="/getprofile"){
        if (request.method === "POST") {
			return request.on('data', function(data) {
			  return request.on('end', function() {
				var query = {  };
				var fmdata = '';
				fmdata += data;
				var info = fmdata.split("&");
				for(var i=0; i<info.length; i++){
					var d = info[i].split("=");
					query[d[0]] = d[1];
				}	
				MongoClient.connect(dbUrl, function(err, db) {
					if (err) throw err;
					var dbo = db.db("mydb");
					dbo.collection("customers").find(query, { projection: { _id: 0, password: 0 } }).toArray(function(err, res) {
						if (err) throw err;
						var r = "";
						for(k1 in res){
							for(k2 in res[k1]){
								r += r == "" ? k2+"="+res[k1][k2] : "&"+k2+"="+res[k1][k2];
							}
						}
						response.end(r); 
						db.close();
					});
				});
			  });

			});
		} else {
			sendFileContent(response, "web.html", "text/html");
		}
	}else if(request.url==="/editinfo"){
        if (request.method === "POST") {
			return request.on('data', function(data) {
			  return request.on('end', function() {
				var query = {  };
				var updateobj = {  };
				var fmdata = '';
				fmdata += data;
				var allinfo = fmdata.split("|");
				var info = allinfo[0].split("&");
				var updateinfo = allinfo[1].split("&");
				for(var i=0; i<info.length; i++){
					var d = info[i].split("=");
					query[d[0]] = d[1];
				}
				for(var i=0; i<updateinfo.length; i++){
					var d = updateinfo[i].split("=");
					updateobj[d[0]] = d[1];
				}
				MongoClient.connect(dbUrl, function(err, db) {
					if (err) throw err;
					var dbo = db.db("mydb");
					dbo.collection("customers").updateOne(query, { $set: updateobj } , function(err, res) {
						if (err) throw err;
						console.log("1 document updated");
						response.end("SUCCESS"); 
						db.close();
					});
				});
			  });

			});
		} else {
			sendFileContent(response, "web.html", "text/html");
		}
	}else if(request.url==="/login"){
        sendFileContent(response, "login.html", "text/html");
	}
	else if(request.url==="/info"){ 
		sendFileContent(response, "info.html", "text/html");
	}
	else if (/^\/[a-zA-Z0-9\/]*.js$/.test(request.url.toString(1))) {
		sendFileContent(response, request.url.toString().substring(1), "text/javascript");
	}
	else if (/^\/[a-zA-Z0-9\/]*.css$/.test(request.url.toString())) 
	{        
		sendFileContent(response, request.url.toString().substring(1), "text/css");
	}
	else if (/^\/[a-zA-Z0-9\/]*.json$/.test(request.url.toString())) 
	{
		sendFileContent(response, request.url.toString().substring(1), "application/json");
	}
	else if (/^\/[a-zA-Z0-9\/]*.ts$/.test(request.url.toString())) 
	{
		sendFileContent(response, request.url.toString().substring(1), "text/javascript");
	}
	else if (/^\/[a-zA-Z0-9\/]*.png$/.test(request.url.toString())) 
	{
		sendFileContent(response, request.url.toString().substring(1), "image/png");
	}
	else if (/^\/[a-zA-Z0-9\/]*.jpg$/.test(request.url.toString())) 
	{
		sendFileContent(response, request.url.toString().substring(1), "image/jpeg");
	}
	else if (/^\/[a-zA-Z0-9\/]*.gif$/.test(request.url.toString())) 
	{
		sendFileContent(response, request.url.toString().substring(1), "image/gif");
	}
	else 
	{
		//console.log("Requested URL : " + request.url + "\n");
		response.end();
	}
}).listen(9999)

function sendFileContent(response, fileName, contentType){
	fs.readFile(fileName, function(err, data){
		if(err){
			response.writeHead(404);
			response.write("Not Found!");
		}
		else{
			response.writeHead(200, {'Content-Type': contentType});
			response.write(data);
		}
		response.end();
	});
}