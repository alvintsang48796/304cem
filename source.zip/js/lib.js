var errormsg = {
	"empty" : "This field can not be blank",
	"pwnotmatch" : "Password not match",
	"pwlength" : "As least 8 characters",
	"loginexist" : "Login name already exists",
	"loginnotexist" : "Invalid user id/password"
};

var themetype = ["default","sea","galaxy","mountain","paper","flower"];

function setstatus(status){
	$("body").attr("status", status);
	clearfm($("#"+status+"fm"));
}

function setloading(){
	var loading = $("<div id='loading' style='display: none;'><img src='images/giphy.gif' /></div>");
	$("body").append(loading);
	$( document ).ajaxStart(function() {
		loading.show();
	});
	$( document ).ajaxComplete(function( event, request, settings ) {
		loading.hide();
	});
}

function clearfm(fm){
	fm.find("input.needinit").val("");
	fm.find(".errmsg").remove();
}

function validfm(fm){
	var errar = [];
	$(fm).find(".req").each(function(){
		if($(this).val().trim() == ""){
			errar.push({
				el: $(this),
				errmsg: errormsg["empty"]
			});
		}
	});
	$(fm).find(".pw").each(function(){
		if(!(/^[0-9a-zA-Z]{8,}$/.test($(this).val()))){
			errar.push({
				el: $(this),
				errmsg: errormsg["pwlength"]
			});
		}
	});
	$(fm).find(".cfmpw").each(function(){
		var cfm = $(fm).find("[name='"+$(this).attr("cfm")+"']");
		if($(this).val() !== cfm.val()){
			errar.push({
				el: $(this),
				errmsg: errormsg["pwnotmatch"]
			});
		}
	});
	if(errar.length == 0){
		var targetitem = $(fm).find("[name='loginname']");
		var loginTxt = targetitem.val();
		var mydata = "loginname="+loginTxt;
		//console.log("mydata: "+mydata);
		$.ajax({
			type: 'POST',
			url: 'http://127.0.0.1:9999/checklogin',
			data: mydata,
			success: function(data) {
				if(data == "SUCCESS"){
					errar.push({
						el: $(targetitem),
						errmsg: errormsg["loginexist"]
					});
					adderr(errar);
				}else{
					regaccount(true);
				}
			},
			error: function(xhr, status, error) {
				console.log('Error: ' + error.message);
			}
		});
	}else{
		adderr(errar);
	}
}

function regaccount(goindex = false){
	var loginTxt = $("#regfm [name='loginname']").val();
	var pass = $("#regfm [name='password']").val();
	var username = $("#regfm [name='username']").val();
	var mydata = "loginname="+loginTxt+"&password="+pass+"&username="+username;
	$.ajax({
		type: 'POST',
		url: 'http://127.0.0.1:9999/reg',
		data: mydata,
		success: function(data) {
			if (data == "SUCCESS") {
				alert("Registion success");
				if(goindex){
					location.href= "/index";
				}
			}else{
				alert("Registion fail");
			}
		},
		error: function(xhr, status, error) {
			console.log('Error: ' + error.message);
		}
	});
}

function existaccountlogin(){
	var targetitem = $("#loginfm [name='loginname']");
	var loginTxt = targetitem.val();
	var pass = $("#loginfm [name='password']").val();
	var mydata = "loginname="+loginTxt+"&password="+pass;
	var errar = [];
	$.ajax({
		type: 'POST',
		url: 'http://127.0.0.1:9999/checklogin',
		data: mydata,
		success: function(data) {
			if (data == "SUCCESS") {
				alert("Login success");
				localStorage.setItem("islogin", "1");
				localStorage.setItem("loginname", loginTxt);
				alert("Welcome " + loginTxt);
				location.href = "/login";
			} else {
				errar.push({
					el: $(targetitem),
					errmsg: errormsg["loginnotexist"]
				});
				adderr(errar);
			}
		},
		error: function(xhr, status, error) {
			console.log('Error: ' + error.message);
		}
	});
}

function adderr(err){
	$(".errmsg").remove();
	for(var i=0; i<err.length; i++){
		$(err[i].el).parent().append("<div class='errmsg'>"+err[i].errmsg+"</div>");
	}
}

function redirectpf(tf){
	var chk = tf == "index" ? localStorage.getItem("islogin") == "1" : localStorage.getItem("islogin") !== "1";
	var others = tf == "index" ? "login" : "index";
	if(chk){
		location.href = "/"+others;
	}
}

function setpage(){
	if($("[load]").length > 0){
		var loadnum = 0;
		$("[load]").each(function(){
			var htmlname = $(this).attr("load");
			console.log($(this));
			$(this).load("menu.html" , function(){
				loadnum++;
				if(loadnum == $("[load]").length){
					if (typeof initfn !== 'undefined' && typeof initfn === "function") {
						initfn();
					}
				}
			});
		});
	}else{
		if (typeof initfn !== 'undefined' && typeof initfn === "function") {
			initfn();
		}
	}
}

function setlogin(){
	var loginTxt = localStorage.getItem("loginname");
	var mydata = "loginname="+loginTxt;
	$.ajax({
		type: 'POST',
		url: 'http://127.0.0.1:9999/getprofile',
		data: mydata,
		success: function(data) {
			var profile = {};
			var info = data.split("&");
			for(var i=0; i<info.length; i++){
				var d = info[i].split("=");
				profile[d[0]] = d[1];
			}
			// requied
			$("#loginname").html(profile["loginname"]);
			$("#username").html(profile["username"]);
			$("#username_edit").val(profile["username"]);
			// not required
			if(profile["gender"] !== undefined) {
				$("[name='gender']").val(profile["gender"]);
				var gendertxt = $("[name='gender'] option[value='"+$("[name='gender']").val()+"']").text();
				$("#gender").html(gendertxt);
				$("#gender_edit").val(profile["gender"]);
				$("[name='gender_edit_rd'][value='"+profile["gender"]+"']").attr('checked', 'checked');
			}else{
				$("#gender").html("unset");
			}
			/* if(profile["bgstyle"] !== undefined) {
				$("[name='bgstyle']").val(profile["bgstyle"]);
				var bgstyletxt = $("[name='bgstyle'] option[value='"+$("[name='bgstyle']").val()+"']").text();
				$("#bgstyle").html(bgstyletxt);
			}else{
				$("#bgstyle").html("default");
			} */
			if(profile["theme"] !== undefined) {
				$("[name='mythemes']").val(profile["theme"]);
			}else{
				$("[name='mythemes']").val(0);
			} 
			if(profile["allthemes"] !== undefined) {
				$("[name='allthemes']").val(profile["allthemes"]);
			}else{
				var themecode = "";
				for(var i=0; i<themetype.length; i++){
					i==0 || i==1 ? themecode += "1" : themecode += "0";
				}
				$("[name='allthemes']").val(themecode);
			} 
			if(profile["intro"] !== undefined && profile["intro"] !== "") {
				$("#intro").html(profile["intro"]);
				$("#intro_edit").val(profile["intro"]);
			}else{
				$("#intro").hide();
			}
			$(".hidefade").removeClass("hidefade");
			setthemes();
			setweather();
		},
		error: function(xhr, status, error) {
			console.log('Error: ' + error.message);
		}
	});
}

function setlogout(){
	localStorage.removeItem("islogin");
	localStorage.removeItem("loginname");
	location.href = "/index";
}

function savebg(){
	var loginTxt = localStorage.getItem("loginname");
	var bgstyle = $("#bgstyle").val();
	var mydata = "loginname="+loginTxt+"|"+"bgstyle="+bgstyle;
	$.ajax({
		type: 'POST',
		url: 'http://127.0.0.1:9999/editinfo',
		data: mydata,
		success: function(data) {
			if (data == "SUCCESS") {
				alert("Modify Success");
			}else{
				alert("Modify Fail");
			}
		},
		error: function(xhr, status, error) {
			console.log('Error: ' + error.message);
		}
	});
}

function saveall(){
	var loginTxt = localStorage.getItem("loginname");
	var gender = $("#gender_edit").val();
	var intro = $("#intro_edit").val();
	var username = $("#username_edit").val();
	var mythemes = $("#mythemes").val();
	var allthemes = $("#allthemes").val();
	var mydata = "loginname="+loginTxt+"|"+"gender="+gender+"&"+"intro="+intro+"&"+"username="+username+"&"+"theme="+mythemes+"&"+"allthemes="+allthemes;
	$.ajax({
		type: 'POST',
		url: 'http://127.0.0.1:9999/editinfo',
		data: mydata,
		success: function(data) {
			if (data == "SUCCESS") {
				alert("Modify Success");
				location.href = "/info";
			}else{
				alert("Modify Fail");
			}
		},
		error: function(xhr, status, error) {
			console.log('Error: ' + error.message);
		}
	});
}

function setweather(){
	var weatherurl = "https://data.weather.gov.hk/weatherAPI/opendata/weather.php?dataType=rhrread&lang=en";
	$.getJSON(weatherurl).done(function(data) {
		// time
		var date = data["updateTime"];
		var formattedDate = new Date(date);
		var d = formattedDate.getDate();
		var m =  formattedDate.getMonth();
		m += 1;  // JavaScript months are 0-11
		var y = formattedDate.getFullYear();
		$("#weatherdate").html(d + "." + m + "." + y);
		
		//temperature
		var temp = data["temperature"]["data"][1]["value"]+"&#8451;";
		$("#weathertemp").html(temp);
		
		//icon
		var iconurl = "http://www.weather.gov.hk//images/HKOWxIconOutline/pic"+data["icon"]+".png";
		$("#weathericon").attr("src", iconurl);
	});
	var furtherweatherurl = "https://data.weather.gov.hk/weatherAPI/opendata/weather.php?dataType=fnd&lang=en";
	$.getJSON(furtherweatherurl).done(function(data) {
		var furtheritems = data["weatherForecast"];
		var daynum = furtheritems.length > 7 ? 7 : furtheritems.length;
		var itemcts = "";
		for (var i = 0; i < daynum; i++) {
			var dayitem = furtheritems[i];
			var week = dayitem["week"].substr(0, 3);
			var icon = "http://www.weather.gov.hk//images/HKOWxIconOutline/pic"+dayitem["ForecastIcon"]+".png";
			var tempmax = dayitem["forecastMaxtemp"]["value"]+"&#8451;";
			var tempmin = dayitem["forecastMintemp"]["value"]+"&#8451;";
			var itemct = "";
			itemct += "<div class='autow-item vtcenter'>";
			itemct += "<div class='week'>"+week+"</div>";
			itemct += "<div class='icon-wrp'><img id='' class='img-contain' src='"+icon+"' /></div>";
			itemct += "<div class='tempmax'>"+tempmax+"</div>";
			itemct += "<div class='tempmin'>"+tempmin+"</div>";
			itemct += "</div>";
			itemcts += itemct;
		}
		$("#furtherweather").html(itemcts);
	});
}

function setthemes(){
	var allthemes = $("[name='allthemes']").val().split("");
	var mythemes = $("[name='mythemes']").val();
	var allthemesct = "";
	var mythemesct = "";
	$("#body").addClass(themetype[$("[name='mythemes']").val()]);
	for(var i=0; i<themetype.length; i++){
		var itemclass = "theme-item p"+(i+1);
		var active = i == mythemes ? " active" : "";
		var added = allthemes[i] == 1 ? "" : " hidden";
		allthemesct +=  "<div class='"+itemclass+"' theme='"+(i+1)+"'></div>";
		mythemesct += '<div class="'+itemclass+active+added+'" onclick="setmytheme('+(i+1)+')"></div>';
	}
	$("#mythemescol").html(mythemesct);
	$("#allthemescol").html(allthemesct);
	sethemesdrag();
}

function setmytheme(idx){
	if(!$("#mythemescol").hasClass("delthemes")){
		/* select theme */
		var num = parseInt(idx);
		$("[name='mythemes']").val(num-1);
		$("#mythemescol .theme-item.active").removeClass("active");
		$("#mythemescol .theme-item.p"+idx).addClass("active");
	}else{
		/*  delete theme */
		if( !$("#mythemescol .theme-item.p"+idx).hasClass("active") ){
			var num = parseInt(idx) - 1;
			var ar = $("#allthemes").val().split("");
			ar[num] = 0;
			var newallthemes = ar.join("");
			$("#allthemes").val(newallthemes);
			$("#mythemescol .theme-item.p"+idx).addClass("hidden")
		}
	}
}

function openedit(){
	$("body").addClass("editinfo");
	$("#edit").show().animate({
		opacity: 1,
	 }, 500);
}

function closeedit(){
	$("body").removeClass("editinfo");
	$("#edit").animate({
		opacity: 0,
	}, 500, function(){
		$("#edit").hide()
	});
}

function opentheme(){
	$("#themes").show().animate({
		opacity: 1,
	 }, 500);
}

function closetheme(){
	$("#themes").animate({
		opacity: 0,
	}, 500, function(){
		$("#themes").hide();
		$("#mythemescol").removeClass("delthemes")
		$("#allthemesblk").hide();
	});
}

function openallthemes(){
	$("#allthemesblk").show().animate({
		opacity: 1,
	 }, 500);
}

function sethemesdrag(){
	$(".allthemes .theme-item").draggable({
		helper: "clone",
		cursor: "move"
	});
	$("#mythemescol").droppable({
		accept: ".allthemes .theme-item",
		drop: function( event, ui ) {
			var allthemes = $("#allthemes");
			var newtheme = parseInt($(ui.draggable).attr("theme"));
			if(allthemes.val().substr((newtheme - 1), 1) == 0){
				var ar = allthemes.val().split("");
				ar[newtheme-1] = 1;
				var newallthemes = ar.join("");
				allthemes.val(newallthemes);
				$("#mythemescol .theme-item.p"+newtheme).removeClass("hidden");
			} 
		}
    });
}

function opendelthemes(){
	$("#mythemescol").addClass("delthemes");
	$("#deltheme").hide();
	$("#backtheme").show();
}

function closedelthemes(){
	$("#mythemescol").removeClass("delthemes");
	$("#deltheme").show();
	$("#backtheme").hide();
}

$(function() {
	setloading();
	setpage();
});